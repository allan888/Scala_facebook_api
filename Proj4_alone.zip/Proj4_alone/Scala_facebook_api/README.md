# Scala_facebook_api
simulated facebook restful server and API based on Scala, akka and spray. 
